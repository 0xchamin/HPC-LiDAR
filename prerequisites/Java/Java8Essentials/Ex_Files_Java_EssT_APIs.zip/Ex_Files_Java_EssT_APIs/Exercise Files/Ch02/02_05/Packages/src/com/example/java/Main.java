package com.example.java;

public class Main {

    public static void main(String[] args) {
        // write your code here
        String input = InputHelper.getInput("Enter value 1: ");
        System.out.println("You entered: " + input);
        input = InputHelper.getInput("Enter value 2: ");
        System.out.println("You entered: " + input);
    }

}
