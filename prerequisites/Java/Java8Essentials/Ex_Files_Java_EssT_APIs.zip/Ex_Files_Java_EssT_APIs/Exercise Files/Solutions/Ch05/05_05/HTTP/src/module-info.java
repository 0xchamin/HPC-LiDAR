module HTTP {
    requires jdk.incubator.httpclient;
}