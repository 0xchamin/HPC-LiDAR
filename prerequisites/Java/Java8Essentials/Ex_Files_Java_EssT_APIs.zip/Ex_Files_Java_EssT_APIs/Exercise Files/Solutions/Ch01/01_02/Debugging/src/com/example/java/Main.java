package com.example.java;

public class Main {

    public static void main(String[] args) {

        String welcome = "Welcome!";
        char[] chars = welcome.toCharArray();
        for (char character :
                chars) {
            System.out.println(character);
        }

    }
}
