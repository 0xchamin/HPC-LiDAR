package com.example.java;

public class Main {

    public static void main(String[] args) {
	// write your code here

//        System.out.println("Hello world");
//        int x = 1;
//        String y = "Hello";

//        String welcome = "Welcome!";
//        char[] chars = welcome.toCharArray();
//        char lastChar = chars[chars.length];
//        System.out.println("last char: " + lastChar);

        String nothing = null;
        System.out.println(nothing);
        System.out.println("string length=" + nothing.length());
    }
}
