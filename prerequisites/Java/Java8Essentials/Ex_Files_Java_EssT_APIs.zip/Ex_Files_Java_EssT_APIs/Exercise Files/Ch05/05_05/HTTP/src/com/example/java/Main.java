package com.example.java;

public class Main {

    private static final String DATA_URL =
            "http://services.hanselandpetal.com/feeds/flowers.json";

    public static void main(String[] args){
	// write your code here
    }
}
