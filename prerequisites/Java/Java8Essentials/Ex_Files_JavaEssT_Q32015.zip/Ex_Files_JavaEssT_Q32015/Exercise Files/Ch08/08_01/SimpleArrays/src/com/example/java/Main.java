package com.example.java;

public class Main {

    public static void main(String[] args) {

        System.out.println("Array of primitives");


        System.out.println("Array of strings");


        System.out.println("Setting an initial size");


        System.out.println("Copying an array");

    }

}
