package com.example.java;

public class Main {

    public static void main(String[] args) {

        double doubleValue = 1_234_567.89;

    }

}
