package com.example.java;

public class Main {

    public static void main(String[] args) {

        int intValue = 42;

        boolean boolValue = true;

        long longValue = 10_000_000;

    }

}
