package com.example.java;

public class MaxValues {

    public static void main(String[] args) {

    }

}
