package com.example.java;

import java.util.Scanner;

public class Calculator2 {



}
