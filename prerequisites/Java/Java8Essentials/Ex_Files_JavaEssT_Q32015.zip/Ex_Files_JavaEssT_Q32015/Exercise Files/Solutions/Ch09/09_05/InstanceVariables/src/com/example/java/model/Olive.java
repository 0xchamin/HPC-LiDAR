package com.example.java.model;

public class Olive {

    public String name = "Kalamata";
    public long color = 0x2E0854;
    public int oil = 3;

}
