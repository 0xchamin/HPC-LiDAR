package com.example.java;

public class Main {

    public static void main(String[] args) {
	    System.out.println("Hello from IDEA!");
        String aString = "David";
        System.out.println("Your name is " + aString);
    }
}
